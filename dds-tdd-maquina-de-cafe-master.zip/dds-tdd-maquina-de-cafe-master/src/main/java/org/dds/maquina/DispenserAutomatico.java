package org.dds.maquina;


public interface DispenserAutomatico {

	void iniciar();

	void dispensarAzucar(float d);

	void dispensarEdulcorante(float cucharadasDeEdulcorante);

}
