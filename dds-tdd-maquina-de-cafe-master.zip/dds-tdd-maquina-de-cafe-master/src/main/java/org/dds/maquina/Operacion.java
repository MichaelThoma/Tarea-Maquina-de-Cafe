package org.dds.maquina;


public interface Operacion {

	void ejecutar();

}
