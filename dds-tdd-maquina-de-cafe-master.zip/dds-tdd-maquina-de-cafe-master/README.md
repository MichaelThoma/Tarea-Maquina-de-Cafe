# dds-tdd-maquina-de-cafe
Diseño de Sistemas - Ejercicio de práctica de TDD

## Para hacerlo andar

Corren el mvn para generar los archivos de eclipse
```
mvn eclipse:eclipse
```
Luego en el workspace de eclipse, botón derecho, import... Existing Project into workspace. Y luego seleccionan la carpeta del proyecto.  

